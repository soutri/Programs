#!/bin/sh

nosetests --nocapture $1
