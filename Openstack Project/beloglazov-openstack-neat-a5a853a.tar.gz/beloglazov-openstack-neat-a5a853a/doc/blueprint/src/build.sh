#!/bin/sh

./build-rst.sh
./build-pdf.sh
./build-epub.sh
./build-html.sh
