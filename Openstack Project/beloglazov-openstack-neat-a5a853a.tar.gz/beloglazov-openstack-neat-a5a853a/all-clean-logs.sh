#!/bin/sh

./compute-clean-logs.py
rm -rf /var/log/neat/*
