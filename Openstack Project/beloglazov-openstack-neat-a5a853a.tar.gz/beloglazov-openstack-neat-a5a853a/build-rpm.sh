#!/bin/sh

python2 setup.py bdist_rpm
