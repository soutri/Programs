#!/bin/sh

chkconfig --add openstack-neat-data-collector
chkconfig --add openstack-neat-db-cleaner
chkconfig --add openstack-neat-global-manager
chkconfig --add openstack-neat-local-manager
